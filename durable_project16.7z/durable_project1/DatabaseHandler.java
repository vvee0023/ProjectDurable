package com.example.durable_project1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseHandler extends SQLiteOpenHelper {
    private static String DATABASE_FILENAME = "Ball.db";
    static final String TABLE_NAME = "mytable";
    //<----------------------------------------------------------------------Variables of this project Column Attributes---------------------------------------------------------------------->//
    static final String TABLE_USER = "User";
    static final String USER_COLUMN_USER_EMAIL = "User_Email";
    static final String USER_COLUMN_USER_PASSWORD = "User_Password";
    static final String TABLE_LOCATION = "Location_DG";
    static final String LOCATION_COLUMN_ID = "Location_Id";
    static final String LOCATION_COLUMN_DETAIL = "Detail";
    static final String LOCATION_COLUMN_NO_CABINET = "No_Cabinet";
    static final String LOCATION_COLUMN_NO_ROOM = "No_Room";
    static final String LOCATION_COLUMN_NO_BUILDING = "No_Building";
    static final String LOCATION_COLUMN_FLOOR = "Floor";
    static final String TABLE_DURABLEGOODS = "Durable_Goods";
    static final String DURABLE_COLUMN_FACUTYID = "FacutyId";
    static final String DURABLE_COLUMN_FACUTYNAME = "FacutyName" ;
    static final String DURABLE_COLUMN_DEPARTMENTID = "DepartmentId";
    static final String DURABLE_COLUMN_DEPARTMENNAME = "DepartmentName";
    static final String DURABLE_COLUMN_BUDGETSOURCEID= "BudgetsourceId";
    static final String DURABLE_COLUMN_BUDGETSOURCE = "Budgetsource";
    static final String DURABLE_COLUMN_BUDGETYEAR = "Budgetyear";

    static final String DURABLE_COLUMN_ID = "_id";

    static final String DURABLE_COLUMN_NAME = "Name";
    static final String DURABLE_COLUMN_ATTRIBUTE = "Attribute";
    static final String DURABLE_COLUMN_DETAIL = "Detail";
    static final String DURABLE_COLUMN_UNIT = "Unit";
    static final String DURABLE_COLUMN_DATEIN = "Datein";
    static final String DURABLE_COLUMN_PRICE = "Price";
    static final String DURABLE_COLUMN_IMPORTER = "Importer";
    static final String DURABLE_COLUMN_LENDER ="Lender";
    static final String DURABLE_COLUMN_LOANDATE = "Loandate";
    static final String DURABLE_COLUMN_RETURNEDDATE = "Returneddate";
    static final String DURABLE_COLUMN_ORDER = "_Order";
    static final String DURABLE_COLUMN_DELIVERYDATE = "Deliverydate";
    static final String DURABLE_COLUMN_CHECKINDATE ="Checkindate";
    static final String DURABLE_COLUMN_STATUS = "Status";
    static final String DURABLE_COLUMN_SELLER = "Seller";
    static final String DURABLE_COLUMN_SERIALNUMBER ="Serialnumber";
    static final String DURABLE_COLUMN_PROPERTYID ="PropertyId";
    static final String DURABLE_COLUMN_PROPERTYCATEGORYCODE ="Propertycategorycode";
    static final String DURABLE_COLUMN_PROPERTYCATEGORYNAME = "Propertycategoryname";
    static final String DURABLE_COLUMN_FUNDCODE ="Fundcode";
    static final String DURABLE_COLUMN_SCHEMECODE ="Schemecode";
    static final String DURABLE_COLUMN_PROJECTCODE ="ProjectCode";
    static final String DURABLE_COLUMN_NOTE = "Note";
    static final String DURABLE_COLUMN_LOCATION_ID = "Location_Id";
    static final String TABLE_DURABLEIMAGE = "DurableGoods_Image";
    static final String DURABLEIMAGE_COLUMN_DURABLE_ID = "Durable_Id";
    static final String DURABLEIMAGE_COLUMN_DURABLE_IMAGE = "Durable_Image";
    static final String TABLE_MANAGE = "Manage";
    static final String MANAGE_COLUMN_USER_EMAIL = "User_Email";
    static final String MANAGE_COLUMN_DURABLE_ID ="Durable_Id";
    //    ex
    private static final String fileName = "export";
    private static final String TableName = "Durable_Goods";
    private static final String tableName = "ImportFile.CSV";

    //column name or attribute in table
    static final String COLUMN_NAME = "name";
    static final String COLUMN_AGE = "age";

    private static final int DATABASE_VERSION = 1;

    private static final String TAG = "my_app";
    SQLiteDatabase db;

    //Constructor
    public DatabaseHandler(Context context){
        super(context, DATABASE_FILENAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){

        db.execSQL("CREATE TABLE " + TABLE_NAME + " (_id INTEGER PRIMARY KEY AUTOINCREMENT , " + COLUMN_NAME +  " TEXT ," + COLUMN_AGE +  " INTEGER );");

        //Project
        db.execSQL("CREATE TABLE " + TABLE_USER +"(User_Email text PRIMARY KEY , " +
                "User_Password text );"); //password ต้อง hash function
        db.execSQL("CREATE TABLE "+ TABLE_LOCATION +"(Location_Id integer PRIMARY KEY, " +
                "Detail text , " +
                "No_Cabinet text, " +
                "No_Room text, " +
                "No_Building text, " +
                "Floor integer );");
        db.execSQL("CREATE TABLE "+ TABLE_DURABLEGOODS +"(FacutyId integer," +
                "FacutyName text,"+
                "DepartmentId integer,"+
                "DepartmentName text,"+
                "BudgetsourceId integer,"+
                "Budgetsource text," +
                "Budgetyear integer,"+
                "_id text PRIMARY KEY ,"+
                "Name text , " +
                "Attribute text , " +
                "Detail text , " +
                "Unit text , " +
                "Datein date, " +
                "Price currency , " +
                "Importer text , " +
                "Lender text , " +
                "Loandate date , " + //วันที่ยืม
                "Returneddate date , " + //วันที่คืน
                "_Order text , " +
                "Deliverydate date , " +
                "Checkindate date , " +
                "Status text , " +
                "Seller text , " +
                "Serialnumber text , " +
                "PropertyId text , " +
                "Propertycategorycode text , " +
                "Propertycategoryname text ,"+
                "Fundcode text , " +
                "Schemecode text , " +
                "ProjectCode text , " +
                "Note text , " +
                "Location_Id  integer ," +
                "FOREIGN KEY (Location_Id) REFERENCES Location_DG(Location_Id) ); ");

        db.execSQL("CREATE TABLE "+ TABLE_DURABLEIMAGE +"(Durable_Id text PRIMARY KEY , " +
                "Durable_Image text , " +
                "FOREIGN KEY (Durable_Id) REFERENCES Durable_Goods(Durable_Id) );");

        db.execSQL("CREATE TABLE "+ TABLE_MANAGE +"(User_Email text , " +
                "Durable_Id text , PRIMARY KEY(User_Email,Durable_Id) ," +
                "FOREIGN KEY (User_Email) REFERENCES User(User_Email) , " +
                "FOREIGN KEY (Durable_Id) REFERENCES Durable_Goods(Durable_Id) );");
        Log.d(TAG,"Created Table");

    }

    public void onUpgrade(SQLiteDatabase db,int oldVersion , int newVersion){
        Log.d(TABLE_NAME,"Updrading database from version" + oldVersion + "to" + newVersion + ",which will destroy all old data");
        db.execSQL(" DROP TABLE IF EXISTS "+TABLE_NAME);

        db.execSQL("DROP TABLE IF EXISTS "+TABLE_USER);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_LOCATION);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_DURABLEGOODS);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_DURABLEIMAGE);
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_MANAGE);

        onCreate(db); //drop แล้วสร้างใหม่
    }

    public long addRecord(String name,int number){
        SQLiteDatabase db = this.getWritableDatabase();  //เปิด db
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME,name);
        values.put(COLUMN_AGE,number);
        long row = db.insert(DatabaseHandler.TABLE_NAME,null,values);

        Log.d(TABLE_NAME,"Inserted at row " + row + " " + name + number);
        db.close();
        return row;

    }

    //<----------------------------------------------------------------------Insert data Into table---------------------------------------------------------------------->//
    public boolean insertIntoUser(String email,String password){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(USER_COLUMN_USER_EMAIL,email);
        contentValues.put(USER_COLUMN_USER_PASSWORD,password);
        long result = db.insert(TABLE_USER,null,contentValues);
        if (result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean insertIntoLocation(int u1,String u2,String u3,String u4,String u5,int u6){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(LOCATION_COLUMN_ID,u1);
        contentValues.put(LOCATION_COLUMN_DETAIL,u2);
        contentValues.put(LOCATION_COLUMN_NO_CABINET,u3);
        contentValues.put(LOCATION_COLUMN_NO_ROOM,u4);
        contentValues.put(LOCATION_COLUMN_NO_BUILDING,u5);
        contentValues.put(LOCATION_COLUMN_FLOOR,u6);
        long result = db.insert(TABLE_LOCATION,null,contentValues);
        if (result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean insertIntoDurable_Goods(int FacutyId,String FacutyName,int DepartmentId,String DepartmentName,int BudgetsourceId,String Budgetsource,int Budgetyear,
                                           String Id,String Name,String Attribute,String Detail,String Unit,String Datein,String Price,
                                           String Importer,String Lender ,String Loandate,String Returneddate,String Order,String Deliverydate,
                                           String Checkindate, String Status,String Seller,String Serialnumber,String PropertyId,String Propertycategorycode,String Propertycategoryname,String Fundcode,
                                           String Schemacode,String Projectcode,String Note,int Location){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DURABLE_COLUMN_FACUTYID,FacutyId);
        contentValues.put(DURABLE_COLUMN_FACUTYNAME,FacutyName);
        contentValues.put(DURABLE_COLUMN_DEPARTMENTID,DepartmentId);
        contentValues.put(DURABLE_COLUMN_DEPARTMENNAME,DepartmentName);
        contentValues.put(DURABLE_COLUMN_BUDGETSOURCEID,BudgetsourceId);
        contentValues.put(DURABLE_COLUMN_BUDGETSOURCE,Budgetsource);
        contentValues.put(DURABLE_COLUMN_BUDGETYEAR,Budgetyear);
        contentValues.put(DURABLE_COLUMN_ID,Id);
        contentValues.put(DURABLE_COLUMN_NAME,Name);
        contentValues.put(DURABLE_COLUMN_ATTRIBUTE,Attribute);
        contentValues.put(DURABLE_COLUMN_DETAIL,Detail);
        contentValues.put(DURABLE_COLUMN_UNIT,Unit);
        contentValues.put(DURABLE_COLUMN_DATEIN,Datein);
        contentValues.put(DURABLE_COLUMN_PRICE,Price);
        contentValues.put(DURABLE_COLUMN_IMPORTER,Importer);
        contentValues.put(DURABLE_COLUMN_LENDER,Lender);
        contentValues.put(DURABLE_COLUMN_LOANDATE,Loandate);
        contentValues.put(DURABLE_COLUMN_RETURNEDDATE,Returneddate);
        contentValues.put(DURABLE_COLUMN_ORDER,Order);
        contentValues.put(DURABLE_COLUMN_DELIVERYDATE,Deliverydate);
        contentValues.put(DURABLE_COLUMN_CHECKINDATE,Checkindate);
        contentValues.put(DURABLE_COLUMN_STATUS,Status);
        contentValues.put(DURABLE_COLUMN_SELLER,Seller);
        contentValues.put(DURABLE_COLUMN_SERIALNUMBER,Serialnumber);
        contentValues.put(DURABLE_COLUMN_PROPERTYID,PropertyId);
        contentValues.put(DURABLE_COLUMN_PROPERTYCATEGORYCODE,Propertycategorycode);
        contentValues.put(DURABLE_COLUMN_PROPERTYCATEGORYNAME,Propertycategoryname);
        contentValues.put(DURABLE_COLUMN_FUNDCODE,Fundcode);
        contentValues.put(DURABLE_COLUMN_SCHEMECODE,Schemacode);
        contentValues.put(DURABLE_COLUMN_PROJECTCODE,Projectcode);
        contentValues.put(DURABLE_COLUMN_NOTE,Note);
        contentValues.put(DURABLE_COLUMN_LOCATION_ID,Location);

        long result = db.insert(TABLE_DURABLEGOODS,null,contentValues);
        if (result==-1){
            return false;
        }else {
            return true;
        }
    }

    public boolean insertIntoDurableImage(String u1,String u2){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DURABLEIMAGE_COLUMN_DURABLE_ID,u1);
        contentValues.put(DURABLEIMAGE_COLUMN_DURABLE_IMAGE,u2);
        long result = db.insert(TABLE_DURABLEIMAGE,null,contentValues);
        if (result==-1){
            return false;
        }else {
            return true;
        }
    }
    public boolean insertIntoManage(String u1,String u2){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(MANAGE_COLUMN_USER_EMAIL,u1);
        contentValues.put(MANAGE_COLUMN_DURABLE_ID,u2);
        long result = db.insert(TABLE_MANAGE,null,contentValues);
        if (result==-1){
            return false;
        }else {
            return true;
        }
    }
    //<----------------------------------------------------------------------END Insert data Into table---------------------------------------------------------------------->//



    //เลือก record ที่ส่งมา
    public String getRecord(long id){
        String data = " ";
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"_id" , "name" , "age"};  //select db column ไหนบ้าง
        Cursor c = db.query(TABLE_NAME,
                columns,
                "_id=?",new String[]{ String.valueOf(id)},
                null,null,null,null);

        Log.d(TABLE_NAME," recID " + id + " count " + c.getCount( ));

        if(c!=null){ //พบ record ตามเงื่อนไข
            if(c.moveToFirst()){    //เลื่อน cursor ไปที่ตัวชี้ที่ row
                int idCol = c.getColumnIndex("_id");
                int nameCol = c.getColumnIndex("name"); //column ชื่อ name
                int ageCol = c.getColumnIndex("age");

                String strId = Integer.toString(c.getInt(idCol)); //read data in column
                String strName = c.getString(nameCol);
                String strAge = Integer.toString(c.getInt(ageCol));

                data = "id" + strId + "\n" + strName + "\n" + strAge + "\n";

            }
        }
        c.close();
        return data;
    }


    //----------------------------------------------------------------------------- Start Get reccord to sent for Edit (แก้ต่อ) --------------------------------------------------------------------------------//
    //เลือก record ที่ส่งมา
    public String[] getRecordDurable(String id){
        String data = " ";
//        String[] data2 = new String[​32];
        String[] data2 = new String[32];
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"*"};  //select db column ไหนบ้าง
        Cursor c = db.query(TABLE_DURABLEGOODS,
                columns,
                "_id=?",new String[]{ String.valueOf(id)},
                null,null,null,null);

        Log.d(TAG," recID " + id + " count " + c.getCount( ));

        if(c != null){ //พบ record ตามเงื่อนไข
            if(c.moveToFirst()){    //เลื่อน cursor ไปที่ตัวชี้ที่ row
                int FacutyIdCol = c.getColumnIndex("FacutyId");
                int FacutyNameCol = c.getColumnIndex("FacutyName");
                int DepartmentIdCol = c.getColumnIndex("DepartmentId");
                int DepartmentNameCol = c.getColumnIndex("DepartmentName");
                int BudgetsourceIdCol = c.getColumnIndex("BudgetsourceId");
                int BudgetsourceCol = c.getColumnIndex("Durable_Budgetsource"); //column ชื่อ name
                int BudgetyearCol = c.getColumnIndex("Budgetyear");
                int idCol = c.getColumnIndex("_id");
                int NameCol = c.getColumnIndex("Name");
                int AttributeCol = c.getColumnIndex("Attribute");
                int DetailCol = c.getColumnIndex("Detail");
                int UnitCol = c.getColumnIndex("Unit");
                int DateinCol = c.getColumnIndex("Datein");
                int PriceCol = c.getColumnIndex("Price");
                int ImporterCol = c.getColumnIndex("Importer");
                int LenderCol = c.getColumnIndex("Lender");
                int LoandateCol = c.getColumnIndex("Loandate");
                int ReturneddateCol = c.getColumnIndex("Returneddate");
                int OrderCol = c.getColumnIndex("_Order");
                int DeliverydateCol = c.getColumnIndex("Deliverydate");
                int CheckindateCol = c.getColumnIndex("Checkindate");
                int StatusCol = c.getColumnIndex("Status");
                int SellerCol = c.getColumnIndex("Seller");
                int SerialnumberCol = c.getColumnIndex("Serialnumber");
                int PropertyIdCol = c.getColumnIndex("PropertyId");
                int PropertycategorycodeCol = c.getColumnIndex("Propertycategorycode");
                int PropertycategorynameCol = c.getColumnIndex("Propertycategoryname");
                int FundcodeCol = c.getColumnIndex("Fundcode");
                int SchemacodeCol = c.getColumnIndex("Schemacode");
                int ProjectCodeCol = c.getColumnIndex("ProjectCode");
                int NoteCol = c.getColumnIndex("Note");
                int LocationCol = c.getColumnIndex("Location_Id");

                String strFacutyId = Integer.toString(c.getInt(FacutyIdCol));
                String strFacutyName = c.getString(FacutyNameCol);
                String strDepartmentId = Integer.toString(c.getInt(DepartmentIdCol));
                String strDepartmentName = c.getString(DepartmentNameCol);
                String strBudgetsourceId = Integer.toString(c.getInt(BudgetsourceIdCol));
                String strBudgetsource = c.getString(BudgetsourceCol);
                String strBudgetyear = Integer.toString(c.getInt(BudgetyearCol));
                String strId = c.getString(idCol); //read data in column
                String strName = c.getString(NameCol);
                String strAttribute = c.getString(AttributeCol);
                String strDetail = c.getString(DetailCol);
                String strUnit = c.getString(UnitCol);
                String strDatein = c.getString(DateinCol);
                String strPrice = c.getString(PriceCol);
                String strImporter = c.getString(ImporterCol);
                String strLender = c.getString(LenderCol);
                String strLoandate = c.getString(LoandateCol);
                String strReturneddate = c.getString(ReturneddateCol);
                String strOrder = c.getString(OrderCol);
                String strDeliverydate = c.getString(DeliverydateCol);
                String strCheckindate= c.getString(CheckindateCol);
                String strStatus = c.getString(StatusCol);
                String strSeller = c.getString(SellerCol);
                String strSerialnumber = c.getString(SerialnumberCol);
                String strPropertyId = c.getString(PropertyIdCol);
                String strPropertycategorycode = c.getString(PropertycategorycodeCol);
                String strPropertycategoryname = c.getString(PropertycategorynameCol);
                String strFundcode = c.getString(FundcodeCol);
                String strSchemacode = c.getString(SchemacodeCol);
                String strProjectcode = c.getString(ProjectCodeCol);
                String strNote = c.getString(NoteCol);
                String strLocation = Integer.toString(c.getInt(LocationCol));

                data = strId + "\n" + strBudgetsource + "\n" + strDatein + "\n" +  strName + "\n" + strDetail + "\n" + strUnit + "\n" + strPrice + "\n" + strOrder + "\n" + strStatus +"\n" + strLoandate +"\n"
                        + strReturneddate + "\n" + strNote +"\n" + strLocation +"\n";

                data2[0] = strFacutyId;
                data2[1] = strFacutyName;
                data2[2] = strDepartmentId;
                data2[3] = strDepartmentName;
                data2[4] = strBudgetsourceId;
                data2[5] = strBudgetsource;
                data2[6] = strBudgetyear;
                data2[7] = strId;
                data2[8] = strName;
                data2[9] = strAttribute;
                data2[10] = strDetail;
                data2[11] = strUnit;
                data2[12] = strDatein;
                data2[13] = strPrice;
                data2[14] = strImporter;
                data2[15] = strLender;
                data2[16] = strLoandate;
                data2[17] = strReturneddate;
                data2[18] = strOrder;
                data2[19] = strDeliverydate;
                data2[20] = strCheckindate;
                data2[21] = strStatus;
                data2[22] = strSeller;
                data2[23] = strSerialnumber;
                data2[24] = strPropertyId;
                data2[25] = strPropertycategorycode;
                data2[26] = strPropertycategoryname;
                data2[27] = strFundcode;
                data2[28] = strSchemacode;
                data2[29] = strProjectcode;
                data2[30] = strNote;
                data2[31] = strLocation;


            }
        }else {
            Log.d(TAG,"Connot open getRecordDurable");
        }
        c.close();
        Log.d(TAG,"Data : " + data);
        return data2;
    }
    //----------------------------------------------------------------------------- End Get reccord to sent for Edit --------------------------------------------------------------------------------//


    //count record
    public int getRecordCount(){
        String countQuery = "SELECT _id FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cur = db.rawQuery(countQuery,null);
        return cur.getCount();
    }

    //Update data record
    public int updateContact(long recID , String name , int number){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, name);
        values.put(COLUMN_AGE, number);

        return db.update(TABLE_NAME ,
                values,
                "_id=?", new String[] { String.valueOf(recID) });
    }

    //-------------------------------------------------------------------------------------------- Start Update Status ------------------------------------------------------------------------------//
    //Update data record
    public int updateStatusRecord(String recID , String status){
        SQLiteDatabase db = this.getWritableDatabase();
        Log.d(TAG,"Udateed : " + status);
        ContentValues values = new ContentValues();
        values.put(DURABLE_COLUMN_STATUS, status);

        return db.update(TABLE_DURABLEGOODS ,
                values,
                "_id=?", new String[] { String.valueOf(recID) });


    }
    //-------------------------------------------------------------------------------------------- Start Update Status ------------------------------------------------------------------------------//


    //read data all record
    public Cursor getAllRecord(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"_id","name","age"}; //เลือก column
        Cursor cur = db.query(TABLE_NAME,
                columns,
                null,null,null,null,null);
        Log.d(TABLE_NAME,"count " + cur.getCount() );
        return cur; //return ค่าเป็น Cursor
    }
    //------------------------------------------------------------------------------- OrderBy DESC AND ASC -------------------------------------------------------------------------------//
    public Cursor getAllRecordOrderByPriceAsc(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"*"}; //เลือก column
        //        String[] columns = {"Durable_Id","Durable_Budgetsource","Durable_Datein","Durable_Name","Durable_Detail","Durable_Unit","Durable_Price","Durable_Order","Durable_Status","Durable_Loandate","Durable_Returneddate","Durable_Note","Location_Id"};
        Cursor cur = db.query(TABLE_DURABLEGOODS,
                columns,
                null,null,null,null,DURABLE_COLUMN_PRICE + " ASC");
        Log.d(TABLE_DURABLEGOODS,"count " + cur.getCount() );
        return cur; //return ค่าเป็น Cursor
    }
    public Cursor getAllRecordOrderByPriceDesc(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"*"}; //เลือก column
//        String[] columns = {"Durable_Id","Durable_Budgetsource","Durable_Datein","Durable_Name","Durable_Detail","Durable_Unit","Durable_Price","Durable_Order","Durable_Status","Durable_Loandate","Durable_Returneddate","Durable_Note","Location_Id"};
        Cursor cur = db.query(TABLE_DURABLEGOODS,
                columns,
                null,null,null,null,DURABLE_COLUMN_PRICE + " DESC");
        Log.d(TABLE_DURABLEGOODS,"count " + cur.getCount() );
        return cur; //return ค่าเป็น Cursor
    }
    //------------------------------------------------------------------------------- END OrderBy DESC AND ASC -------------------------------------------------------------------------------//
//------------------------------------------------------------------------------- OrderBy Durable ID -------------------------------------------------------------------------------//
    public Cursor getAllRecordOrderByDurableIDASC(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"*"}; //เลือก column
        Cursor cur = db.query(TABLE_DURABLEGOODS,
                columns,
                null,null,null,null,DURABLE_COLUMN_ID + " ASC");
        Log.d(TABLE_DURABLEGOODS,"count " + cur.getCount() );
        Log.d(TAG,"ID ASC :");
        return cur; //return ค่าเป็น Cursor
    }
    public Cursor getAllRecordOrderByDurableIDDESC(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"*"}; //เลือก column
        Cursor cur = db.query(TABLE_DURABLEGOODS,
                columns,
                null,null,null,null,DURABLE_COLUMN_ID + " DESC");
        Log.d(TABLE_DURABLEGOODS,"count " + cur.getCount() );
        Log.d(TAG,"ID DESC :");
        return cur; //return ค่าเป็น Cursor
    }
//------------------------------------------------------------------------------- END OrderBy Durable ID -------------------------------------------------------------------------------//

    //------------------------------------------------------------------------------- OrderBy Durable DateIn -------------------------------------------------------------------------------//
    public Cursor getAllRecordOrderByDurableDateinASC(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"*"}; //เลือก column
        Cursor cur = db.query(TABLE_DURABLEGOODS,
                columns,
                null,null,null,null,DURABLE_COLUMN_DATEIN + " ASC");
        Log.d(TABLE_DURABLEGOODS,"count " + cur.getCount() );
        return cur; //return ค่าเป็น Cursor
    }
    public Cursor getAllRecordOrderByDurableDateinDESC(){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"*"}; //เลือก column
        Cursor cur = db.query(TABLE_DURABLEGOODS,
                columns,
                null,null,null,null,DURABLE_COLUMN_DATEIN + " DESC");
        Log.d(TABLE_DURABLEGOODS,"count " + cur.getCount() );
        return cur; //return ค่าเป็น Cursor
    }
//------------------------------------------------------------------------------- END OrderBy Durable DateIn -------------------------------------------------------------------------------//


    //Search ค้นหาชื่อ
    public Cursor getSearchedRecord(String search){
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"_id","name","age"};
        Cursor cur = db.query(TABLE_NAME,columns,
                "name LIKE ?",new String[]{"%"+search+"%"},
                null,null,null,null);
        Log.d(TABLE_NAME,"count" + cur.getCount() );
        return cur;
    }

    //deleted
    public void deleteRecord(long recID){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME,"_id=?",new String[] {String.valueOf(recID)});
        db.close();
    }


    //---------------------------------------------------------------------- Start EXPORT FILE TO .CSV ----------------------------------------------------//
    public void exportToCSV(){
//        File exportDir = new File(Environment.getExternalStorageDirectory(), "");
        String exportDir = "/data/data/com.example.dbinbook/databases";
//        if (!exportDir.exists()) {
//            exportDir.mkdirs();
//        }

        File file = new File(exportDir, fileName + ".csv");
        try {
            //add
            CSVWriter csvWrite = new CSVWriter(new FileWriter(file));
            SQLiteDatabase db = this.getWritableDatabase();
            //add end
            file.createNewFile();
            String[] columns = {"*"}; //เลือก column
            Cursor curCSV = db.query(TableName,
                    columns,
                    null,null,null,null,DURABLE_COLUMN_DATEIN + " ASC");
//            Cursor curCSV = db.query("SELECT * FROM " + TableName, null);
            csvWrite.writeNext(curCSV.getColumnNames());
            while (curCSV.moveToNext()) {
                //Which column you want to exprort
                String arrStr[] = new String[curCSV.getColumnCount()];
                for (int i = 0; i < curCSV.getColumnCount() - 1; i++)
                    arrStr[i] = curCSV.getString(i);
                csvWrite.writeNext(arrStr);
            }
            csvWrite.close();
            curCSV.close();
//            ToastHelper.showToast(this, "Exported", Toast.LENGTH_SHORT);
//            Toast.makeText(getApplicationContext(),"Exported",Toast.LENGTH_LONG).show();
            Log.d(TAG,"Exported .CSV");
        } catch (Exception sqlEx) {
            Log.e("MainActivity", sqlEx.getMessage(), sqlEx);
            Log.d(TAG,"Not Success");
        }
    }
    //---------------------------------------------------------------------- End Export File TO .CSV ----------------------------------------------------//
    //---------------------------------------------------------------------- Start Import File To .CSV ----------------------------------------------------//

    //---------------------------------------------------------------------- End Export FILE TO .CSV ----------------------------------------------------//
    //---------------------------------------------------------------------- Start import FILE TO .CSV ----------------------------------------------------//

    public ArrayList<HashMap<String, String>> getAllProducts() {
        Log.d(TAG,"Func : ");
        ArrayList<HashMap<String, String>> productList;
        productList = new ArrayList<HashMap<String, String>>();
        String selectQuery = "SELECT  * FROM " + TABLE_LOCATION;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                //Id, Company,Name,Price
                HashMap<String, String> map = new HashMap<String, String>();
                map.put("a", cursor.getString(0));
                map.put("b", cursor.getString(1));
                map.put("c", cursor.getString(2));
                map.put("d", cursor.getString(3));
                map.put("e", cursor.getString(4));
                map.put("f", cursor.getString(5));
                map.put("g", cursor.getString(6));
                map.put("h", cursor.getString(7));
                map.put("i", cursor.getString(8));
                map.put("j", cursor.getString(9));
                map.put("k", cursor.getString(10));
                map.put("l", cursor.getString(11));
                map.put("m", cursor.getString(12));
                map.put("n", cursor.getString(13));
                map.put("o", cursor.getString(14));
                map.put("p", cursor.getString(15));
                map.put("q", cursor.getString(16));
                map.put("r", cursor.getString(17));
                map.put("s", cursor.getString(18));
                map.put("t", cursor.getString(19));
                map.put("u", cursor.getString(20));
                map.put("v", cursor.getString(21));
                map.put("w", cursor.getString(22));
                map.put("x", cursor.getString(23));
                map.put("y", cursor.getString(24));
                map.put("z", cursor.getString(25));
                map.put("aa", cursor.getString(26));
                map.put("ab", cursor.getString(27));
                map.put("ac", cursor.getString(28));
                map.put("ad", cursor.getString(29));
                map.put("ae", cursor.getString(30));
                map.put("af", cursor.getString(31));

                productList.add(map);
                Log.d(TAG, cursor.getString(0) + "," + cursor.getString(1) + "," + cursor.getString(2));
            } while (cursor.moveToNext());
        }
        return productList;

    }

    //---------------------------------------------------------------------- End import FILE TO .CSV ----------------------------------------------------//
    //---------------------------------------------------------------------- Start Spinner ----
    //เลือก record ที่ส่งมา
    public String getRecordSpinner(String id){
        String data = " ";
        SQLiteDatabase db = this.getWritableDatabase();
        String[] columns = {"Durable_Status"};  //select db column ไหนบ้าง
        Cursor c = db.query(TABLE_DURABLEGOODS,
                columns,
                "_id=?",new String[]{ String.valueOf(id)},
                null,null,null,null);

        if(c!=null){ //พบ record ตามเงื่อนไข
            if(c.moveToFirst()){    //เลื่อน cursor ไปที่ตัวชี้ที่ row
                int StatusCol = c.getColumnIndex("Durable_Status");

                String strStatus = c.getString(StatusCol);

                data = strStatus;

            }
        }
        c.close();
        return data;
    }


}
