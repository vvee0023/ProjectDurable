package com.example.durable_project1;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.camera2.CameraDevice;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;

import static android.app.Activity.RESULT_CANCELED;
import static android.app.Activity.RESULT_OK;

public class Fragment3 extends Fragment {

    private static final int PERMISSION_CODE = 1000;
    private static final int IMAGE_CAPTURE_CODE = 1001;
    private static final int PERMISSION_CODE2 = 1000;
    private static final int IMAGE_CAPTURE_CODE2 = 1001;

    ImageView img_pre;
    Button camera_call;
    ImageView img_pre2;
    Button camera_call2;
    Uri image_uri;
    Uri image_uri2;
    CameraDevice cameraDevice;
    Context context;
    Context context2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_fragment3, container, false);

        context = view.getContext();
        context2 = view.getContext();

        img_pre = view.findViewById(R.id.ImagePreview);
        camera_call = view.findViewById(R.id.camera_call);
        img_pre2 = view.findViewById(R.id.ImagePreview2);
        camera_call2 = view.findViewById(R.id.camera_call2);


        camera_call2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cameraClick2();
            }
        });


        camera_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cameraClick();
            }
        });




        return view;
    }

    private void cameraClick() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            String[] permission = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            //show popup to request permissions
            requestPermissions(permission, PERMISSION_CODE);
        } else {
            //permission already granted
            openCamera();
        }
    }

    private void openCamera() {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Images.Media.TITLE, "New Picture");
        values.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        image_uri = Objects.requireNonNull(getActivity()).getApplicationContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
        //Camera intent
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, image_uri);
        startActivityForResult(cameraIntent, IMAGE_CAPTURE_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //called when image was captured from camera
        if (resultCode == RESULT_OK) {
            if (requestCode == IMAGE_CAPTURE_CODE) {
                //set the image captured to our ImageView
                //img_pre.setImageURI(image_uri);
                Picasso.get().load(image_uri).into(img_pre);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //this method is called, when user presses Allow or Deny from Permission Request Popup
        if (requestCode == PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //permission from popup was granted
                openCamera();
            } else {
                //permission from popup was denied
                Toast.makeText(context, "Permission denied...", Toast.LENGTH_SHORT).show();
            }
        }
    }



    private void cameraClick2() {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            String[] permission = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            //show popup to request permissions
            requestPermissions(permission, PERMISSION_CODE);
        } else {
            //permission already granted
            openCamera2();
        }
    }

    private void openCamera2() {
        ContentValues values2 = new ContentValues();
        values2.put(MediaStore.Images.Media.TITLE, "New Picture");
        values2.put(MediaStore.Images.Media.DESCRIPTION, "From the Camera");
        image_uri2 = Objects.requireNonNull(getActivity()).getApplicationContext().getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values2);
        //Camera intent
        Intent cameraIntent2 = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent2.putExtra(MediaStore.EXTRA_OUTPUT, image_uri2);
        startActivityForResult(cameraIntent2, IMAGE_CAPTURE_CODE2);
    }

  /* @Override
    public void onActivityResult2(int requestCode2, int resultCode2, Intent data) {
        //called when image was captured from camera
        if (resultCode2 == RESULT_OK) {
            if (requestCode2 == IMAGE_CAPTURE_CODE2) {
                //set the image captured to our ImageView
                //img_pre.setImageURI(image_uri);
                Picasso.get().load(image_uri2).into(img_pre2);
            }
        }
        super.onActivityResult2(requestCode2, resultCode2, data);
    }

    @Override
    public void onRequestPermissionsResult2(int requestCode2, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //this method is called, when user presses Allow or Deny from Permission Request Popup
        if (requestCode2 == PERMISSION_CODE2) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //permission from popup was granted
                openCamera2();
            } else {
                //permission from popup was denied
                Toast.makeText(context2, "Permission denied...", Toast.LENGTH_SHORT).show();
            }
        }
    }*/

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.submit:
                Context context = getActivity().getApplicationContext();
                Intent intent = new Intent(context, Fragment2.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                break;

        }
    }

}
