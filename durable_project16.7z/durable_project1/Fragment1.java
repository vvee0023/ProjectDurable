package com.example.durable_project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class Fragment1 extends Fragment {

    ImageButton btbimport;

    ImageButton btbexport;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_fragment1,container,false);

        btbimport = (ImageButton) view.findViewById(R.id.btbexport);
        btbimport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "You Clicked to Import!", Toast.LENGTH_LONG).show();

            }
        });

        btbexport = (ImageButton) view.findViewById(R.id.btbimport);
        btbexport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "You Clicked to Export!", Toast.LENGTH_LONG).show();

            }
        });


        return view;

    }

}


