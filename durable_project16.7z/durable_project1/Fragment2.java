package com.example.durable_project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Fragment2 extends Fragment implements View.OnClickListener {


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_fragment2, container, false);
        Button b = (Button) view.findViewById(R.id.detail);
        b.setOnClickListener(this);

        TableRow.LayoutParams wrapWrapTableRowParams = new TableRow.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        int[] fixedColumnWidths = new int[]{20, 20, 20, 20, 20/*,20, 20, 20, 20, 20,20, 20, 20, 20, 20,20, 20, 20, 20, 20,20, 20, 20, 20, 20,20, 20, 20, 20, 20,20, 20, 20, 20, 20,20, 20, 20, 20, 20*/};
        int[] scrollableColumnWidths = new int[]{20, 20, 20, 30, 30/*, 20, 20, 20, 30, 30, 20, 20, 20, 30, 30, 20, 20, 20, 30, 30, 20, 20, 20, 30, 30, 20, 20, 20, 30, 30, 20, 20, 20, 30, 30, 20, 20*/};
        int fixedRowHeight = 50;
        int fixedHeaderHeight = 60;

        TableRow row = new TableRow(getActivity());
        //header (fixed vertically)
        TableLayout header = (TableLayout) view.findViewById(R.id.table_header);
        row.setLayoutParams(wrapWrapTableRowParams);
        row.setGravity(Gravity.CENTER);
        row.setBackgroundColor(Color.YELLOW);
        row.addView(makeTableRowWithText("รหัสคณะ", fixedColumnWidths[0], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ชื่อคณะ", fixedColumnWidths[1], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รหัสภาค/กอง", fixedColumnWidths[2], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ชื่อภาค/กอง", fixedColumnWidths[3], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รหัสแหล่งเงิน", fixedColumnWidths[4], fixedHeaderHeight));
       /* row.addView(makeTableRowWithText("ชื่อแหล่งงบประมาณ", fixedColumnWidths[5], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ปีงบประมาณ", fixedColumnWidths[6], fixedHeaderHeight));
        row.addView(makeTableRowWithText("หมายเลขครุภัณฑ์", fixedColumnWidths[7], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ชื่อครุภัณฑ์", fixedColumnWidths[8], fixedHeaderHeight));
        row.addView(makeTableRowWithText("คุณสมบัติ", fixedColumnWidths[9], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รายชะเอียด", fixedColumnWidths[10], fixedHeaderHeight));
        row.addView(makeTableRowWithText("หน่วยนับ", fixedColumnWidths[11], fixedHeaderHeight));
        row.addView(makeTableRowWithText("วันที่รับเข้าคลัง", fixedColumnWidths[12], fixedHeaderHeight));
        row.addView(makeTableRowWithText("มูลค่าครุภัณฑ์", fixedColumnWidths[13], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ผู้นำเข้าคลัง", fixedColumnWidths[14], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ผู้ยืม", fixedColumnWidths[15], fixedHeaderHeight));
        row.addView(makeTableRowWithText("วันที่ยืม", fixedColumnWidths[16], fixedHeaderHeight));
        row.addView(makeTableRowWithText("วันที่คืน", fixedColumnWidths[17], fixedHeaderHeight));
        row.addView(makeTableRowWithText("เลขที่ใบส่งของ", fixedColumnWidths[18], fixedHeaderHeight));
        row.addView(makeTableRowWithText("วันที่ส่งของ", fixedColumnWidths[19], fixedHeaderHeight));
        row.addView(makeTableRowWithText("วันที่ตรวจรับ", fixedColumnWidths[20], fixedHeaderHeight));
        row.addView(makeTableRowWithText("สถานะ", fixedColumnWidths[21], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ผู้ขาย", fixedColumnWidths[22], fixedHeaderHeight));
        row.addView(makeTableRowWithText("หมายเลข Serial", fixedColumnWidths[23], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รหัสสินทรัพย์", fixedColumnWidths[24], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รหัสกองทุน", fixedColumnWidths[25], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ชื่อกองทุน", fixedColumnWidths[26], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รหัสกองทุน", fixedColumnWidths[27], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รหัสแผนงาน", fixedColumnWidths[28], fixedHeaderHeight));
        row.addView(makeTableRowWithText("รหัสโครงการ", fixedColumnWidths[29], fixedHeaderHeight));
        row.addView(makeTableRowWithText("โน๊ต", fixedColumnWidths[30], fixedHeaderHeight));
        row.addView(makeTableRowWithText("ตำแหน่ง", fixedColumnWidths[31], fixedHeaderHeight));*/
        header.addView(row);
        //header (fixed horizontally)
        TableLayout fixedColumn = (TableLayout) view.findViewById(R.id.fixed_column);
        //rest of the table (within a scroll view)
        TableLayout scrollablePart = (TableLayout) view.findViewById(R.id.scrollable_part);
        for(int i = 0; i < 1; i++  ) {
            TextView fixedView = makeTableRowWithText("row number " + i, scrollableColumnWidths[0], fixedRowHeight);
            fixedView.setBackgroundColor(Color.BLUE);
            fixedColumn.addView(fixedView);
            row = new TableRow(getActivity());
            row.setLayoutParams(wrapWrapTableRowParams);
            row.setGravity(Gravity.CENTER);
            row.setBackgroundColor(Color.WHITE);
            row.addView(makeTableRowWithText("value 1", scrollableColumnWidths[1], fixedRowHeight));
            row.addView(makeTableRowWithText("value 2", scrollableColumnWidths[2], fixedRowHeight));
            row.addView(makeTableRowWithText("value 3", scrollableColumnWidths[3], fixedRowHeight));
            row.addView(makeTableRowWithText("value 4", scrollableColumnWidths[4], fixedRowHeight));
           /* row.addView(makeTableRowWithText("value 5", scrollableColumnWidths[5], fixedRowHeight));
            row.addView(makeTableRowWithText("value 6", scrollableColumnWidths[6], fixedRowHeight));
            row.addView(makeTableRowWithText("value 7", scrollableColumnWidths[7], fixedRowHeight));
            row.addView(makeTableRowWithText("value 8", scrollableColumnWidths[8], fixedRowHeight));
            row.addView(makeTableRowWithText("value 9", scrollableColumnWidths[9], fixedRowHeight));
            row.addView(makeTableRowWithText("value 10", scrollableColumnWidths[10], fixedRowHeight));
            row.addView(makeTableRowWithText("value 11", scrollableColumnWidths[11], fixedRowHeight));
            row.addView(makeTableRowWithText("value 12", scrollableColumnWidths[12], fixedRowHeight));
            row.addView(makeTableRowWithText("value 13", scrollableColumnWidths[13], fixedRowHeight));
            row.addView(makeTableRowWithText("value 14", scrollableColumnWidths[14], fixedRowHeight));
            row.addView(makeTableRowWithText("value 15", scrollableColumnWidths[15], fixedRowHeight));
            row.addView(makeTableRowWithText("value 16", scrollableColumnWidths[16], fixedRowHeight));
            row.addView(makeTableRowWithText("value 17", scrollableColumnWidths[17], fixedRowHeight));
            row.addView(makeTableRowWithText("value 18", scrollableColumnWidths[18], fixedRowHeight));
            row.addView(makeTableRowWithText("value 19", scrollableColumnWidths[19], fixedRowHeight));
            row.addView(makeTableRowWithText("value 20", scrollableColumnWidths[20], fixedRowHeight));
            row.addView(makeTableRowWithText("value 21", scrollableColumnWidths[21], fixedRowHeight));
            row.addView(makeTableRowWithText("value 22", scrollableColumnWidths[22], fixedRowHeight));
            row.addView(makeTableRowWithText("value 23", scrollableColumnWidths[23], fixedRowHeight));
            row.addView(makeTableRowWithText("value 24", scrollableColumnWidths[24], fixedRowHeight));
            row.addView(makeTableRowWithText("value 25", scrollableColumnWidths[25], fixedRowHeight));
            row.addView(makeTableRowWithText("value 26", scrollableColumnWidths[26], fixedRowHeight));
            row.addView(makeTableRowWithText("value 27", scrollableColumnWidths[27], fixedRowHeight));
            row.addView(makeTableRowWithText("value 28", scrollableColumnWidths[28], fixedRowHeight));
            row.addView(makeTableRowWithText("value 29", scrollableColumnWidths[29], fixedRowHeight));
            row.addView(makeTableRowWithText("value 30", scrollableColumnWidths[30], fixedRowHeight));
            row.addView(makeTableRowWithText("value 31", scrollableColumnWidths[31], fixedRowHeight));*/

            scrollablePart.addView(row);
        }


        return view;
    }


    private TextView recyclableTextView;

    public TextView makeTableRowWithText(String text, int widthInPercentOfScreenWidth, int fixedHeightInPixels) {
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        recyclableTextView = new TextView(getActivity());
        recyclableTextView.setText(text);
        recyclableTextView.setTextColor(Color.BLACK);
        recyclableTextView.setTextSize(20);
        recyclableTextView.setWidth(widthInPercentOfScreenWidth * screenWidth / 100);
        recyclableTextView.setHeight(fixedHeightInPixels);
        return recyclableTextView;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.detail:
                Context context = getActivity().getApplicationContext();
                Intent intent = new Intent(context, Details.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                break;
        }
    }
}