package com.example.durable_project1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleCursorAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ViewRecordActivity extends Activity implements AdapterView.OnItemSelectedListener {
    private static final String TAG = "my_app";
    static final String TABLE_DURABLEGOODS = "Durable_Goods";
    String recID;

    private Cursor cursor;
    private SimpleCursorAdapter adapter;
    private DatabaseHandler mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_record);

        //รับ number of record
        recID = getIntent().getStringExtra("recID");
//        Integer i=Integer.valueOf(recID);
        Log.i(TAG,"recID :  "+recID);
        DatabaseHandler mydb = new DatabaseHandler(this);
//        String strData = mydb.getRecord(recID);
        String[] strData = mydb.getRecordDurable(recID);
//        String strData = mydb.getRecordDurable(recID);



//        tv.setText(strData[6]);
//        tv.setTextSize(22);

        EditText etId = (EditText)findViewById(R.id.etId);
        EditText etBudgetsource = (EditText)findViewById(R.id.etBudgetsource);
        EditText etDatein = (EditText)findViewById(R.id.etDatein);
        EditText etName = (EditText)findViewById(R.id.etName);
        EditText etDetail = (EditText)findViewById(R.id.etDetail);
        EditText etUnit = (EditText)findViewById(R.id.etUnit);
        EditText etPrice = (EditText)findViewById(R.id.etPrice);
        EditText etOrder = (EditText)findViewById(R.id.etOrder);
        EditText etStaus = (EditText)findViewById(R.id.etStaus);
        EditText etLoandate = (EditText)findViewById(R.id.etLoandate);
        EditText etReturnneddate = (EditText)findViewById(R.id.etReturnneddate);
        EditText etNote = (EditText)findViewById(R.id.etNote);
        EditText etLocationt = (EditText)findViewById(R.id.etLocation);

        etId.setText(strData[0]);
        etBudgetsource.setText(strData[1]);
        etDatein.setText(strData[2]);
        etName.setText(strData[3]);
        etDetail.setText(strData[4]);
        etUnit.setText(strData[5]);
        etPrice.setText(strData[6]);
        etOrder.setText(strData[7]);
        etStaus.setText(strData[8]);
        etLoandate.setText(strData[9]);
        etReturnneddate.setText(strData[10]);
        etNote.setText(strData[11]);
        etLocationt.setText(strData[12]);

        String spin = mydb.getRecordSpinner(recID);
        Spinner spinner = findViewById(R.id.spinner1);
        spinner.setOnItemSelectedListener(this);
        //get the spinner from the xml.
        //create a list of items for the spinner.
        List<String> list = new ArrayList<String>();
        list.add("Default");
        list.add("ปกติ");
        list.add("ชำรุด");
        list.add("เสื่อมคุณภาพ");
        list.add("สูญหาย");
        list.add("ปรับโอน");
        list.add("ถูกโจรกรรม");
        list.add("ตรวจไม่พบ");
        list.add("ไม่มีหมายเลขทะเบียน");
        list.add("ไม่ตรงตามบัญชี");
        list.add("จำหน่ายแล้ว");
        list.add("ไม่จำเป็นต้องใใช้");
        list.add("อื่นๆ");
//        "Default","ปกติ", "ชำรุด","เสื่อมคุณภาพ","สูญหาย","ปรัับโอน","ถูกโจรกรรม","ตรวจไม่พบ","ไม่มีหมายเลขทะเบียน","ไม่ตรงตามบัญชี","จำหน่ายแล้ว","ไม่จำเป็นต้องใใช้","อื่นๆ"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);



    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position,
                               long id) {
        // On selecting a spinner item
        final String label = parent.getItemAtPosition(position).toString();
        // Showing selected spinner item
        Toast.makeText(parent.getContext(), "You selected: " + label,
                Toast.LENGTH_LONG).show();
        mydb = new DatabaseHandler(this); //Instance connect DB
        Button btnUpdate = (Button) findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) {
                mydb.updateStatusRecord(recID,label);
            }
        });
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

//    public void CheckEditTextStatus(){
//        NameHolder = editTextName.getText().toString() ;
//        NumberHolder = editTextPhoneNumber.getText().toString();
//        if(TextUtils.isEmpty(NameHolder) || TextUtils.isEmpty(NumberHolder)){
//            EditTextEmptyHold = false ;
//        }
//        else {
//            EditTextEmptyHold = true ;
//        }
//    }
//
//    public void EmptyEditTextAfterDataInsert(){
//        editTextName.getText().clear();
//        editTextPhoneNumber.getText().clear();
//    }

}